User routes
To Register Users 

//@route    POST api/users
//@desc     Register user
//@access   Public


//@route    GET api/auth
//@desc     Test route
//@access   Public

when user logs in

//@route    POST api/auth
//@desc     Authenticate user & get token 
//@access   Public

ToDo routes
Create ToDo

// @route    POST api/todos
// @desc     Create a todo
// @access   Private

Get all todos

// @route    GET api/todos
// @desc     Get all todos
// @access   Private

// @route    GET api/todos/:id
// @desc     Get post by ID
// @access   Private

// @route    DELETE api/todos/:id
// @desc     Delete a todo
// @access   Private

// @route    PUT api/todos/:id
// @desc     Update a todo
// @access   Private


